# DevNest 再編 変更点サマリー

> **文書ID**: CHANGE-001
> **対象**: 全10Phase・全設計書・全実装計画
> **起因**: 機能統合レビュー (`devnest-feature-consolidation-review.md`)

---

## 1. Phase構成の変更

### Phase番号の再割り当て

| 新Phase | 旧Phase | 名称 | 変更種別 |
|---------|---------|------|---------|
| 1 | 1 | ドキュメントマッピング基盤 | 変更なし |
| 2 | 2 | 保守管理基盤 | 軽微変更 |
| 3 | 3 | マルチプロダクト基盤 | 軽微変更 |
| 4 | 4 | Agentic Flowエンジン | 軽微変更 |
| 5 | 5 | ワークフロー & PR連携 | 変更なし |
| **6** | 6 + 新規 | **共通基盤 & AI開発アシスタント** | **大幅変更** |
| **7** | **9** | **MCP統合基盤** | **前倒し** |
| **8** | 8 | **アジャイルエンジン** | **縮小** |
| **9** | **7** | **分析 & インサイト** | **後ろ倒し** |
| **10** | 10 | **拡張 & コラボレーション** | **縮小** |

### 依存関係の改善

```
【旧】循環的な依存あり
Phase 7(分析) → Phase 8(カンバン)のデータが必要
Phase 8(カンバン) → Phase 9(MCP)のGitHub同期が必要

【新】完全な順方向依存
Phase 6(core/AI) → Phase 7(MCP) → Phase 8(アジャイル) → Phase 9(分析) → Phase 10(コラボ)
```

---

## 2. 新設モジュール

### core/ 共通基盤層

| ファイル | 吸収元 | 内容 |
|---------|--------|------|
| `core/git_analysis.rs` | maintenance/refactor.rsのchurn分析 + analytics/velocity.rsのcommit集計 + doc_mapping/diff_analyzer.rsのdiff解析 | Git操作の統一層 |
| `core/claude_gateway.rs` | agent/claude_bridge.rs + ai/context_engine.rsのプロンプト生成 | Claude Code呼び出しの統一層 |
| `core/github_gateway.rs` | product/github_sync.rsのoctocrab直接 + mcp/adapters/github.rsのMCP経由 | GitHub操作の統一層（MCP/API自動切替） |

### review/ 統合レビューモジュール

| ファイル | 吸収元 | 内容 |
|---------|--------|------|
| `review/engine.rs` | agent/task.rsのPrQualityCheck + ai/review_agent.rs | 統合レビューエンジン |
| `review/findings.rs` | 新規 | Finding/Severity/Category定義 |
| `review/reporter.rs` | 新規 | PRコメント化、UI表示変換 |

### policy/ 統合ポリシーモジュール

| ファイル | 吸収元 | 内容 |
|---------|--------|------|
| `policy/engine.rs` | agent/policy.rs + mcp/policy.rs | 統合ポリシーエンジン |
| `policy/rules.rs` | 新規 | ルール定義 |
| `policy/audit.rs` | 新規 | 監査ログ |

---

## 3. 削除・延期した機能

| 機能 | 旧タスク | 判断 | 理由 |
|------|---------|------|------|
| カスタムMCPサーバー開発基盤 | 旧9e (Task 9.6-9.7の一部) | 延期 | 既存MCPサーバーで当面十分 |
| ストーリーマッピング | 旧8.4 | 延期 | 個人開発にはカンバンで十分 |
| マルチエージェントScrum | 旧10.3 | 分離 | scrum-agentsは独立プロジェクトとして進化 |
| Claude Code MCP移行 | 旧9.5 | 延期 | claude_gateway統一層で将来の移行は容易 |
| Redmine MCP | 旧9.4 | Phase 10に延期 | 職場での実需確認後 |

**タスク数**: 41 → 32（9タスク削減）

---

## 4. 既存モジュールの変更

### 変更されるファイル

| ファイル | 変更内容 |
|---------|---------|
| `doc_mapping/diff_analyzer.rs` | diff解析をcore/git_analysis.rsに委譲。自身は影響設計書の特定に専念 |
| `maintenance/tech_debt.rs` | DocDrift検出をstaleness.rsの結果参照に変更。独自の鮮度計算を削除 |
| `maintenance/refactor.rs` | churn分析をcore/git_analysis.rsに委譲。スコア算出に専念 |
| `maintenance/coverage.rs` | 変更なし（analytics/velocity.rsがこちらを参照する方向に統一） |
| `product/github_sync.rs` | **削除** → core/github_gateway.rsに統合 |
| `agent/claude_bridge.rs` | **削除** → core/claude_gateway.rsに統合 |
| `agent/policy.rs` | **削除** → policy/engine.rsに統合 |
| `agent/task.rs` | PrQualityCheckのハンドラをreview/engine.rsへの委譲に変更 |

### 削除されるファイル

```
agent/claude_bridge.rs    → core/claude_gateway.rs
agent/policy.rs           → policy/engine.rs
product/github_sync.rs    → core/github_gateway.rs
ai/review_agent.rs        → review/engine.rs
mcp/policy.rs             → policy/engine.rs
```

---

## 5. UI画面の変更

| 旧画面 | 新画面 | 変更内容 |
|--------|--------|---------|
| Portfolio Dashboard | 🏠 Home Dashboard | Agent Activityパネルを統合 |
| Agent Dashboard | 🤖 Agent Control | Approval Gateを統合 |
| Approval Gate | 🤖 Agent Control | Agent Dashboardに統合 |
| Maintenance Dashboard | 📋 Project View [Maintenance] | タブ化 |
| Analytics Dashboard | 📋 Project View [Analytics] | タブ化 |
| AI Assistant | 📋 Project View [AI Review] | タブ化 |
| Kanban Board | 📋 Project View [Kanban] | タブ化 |
| MCP Manager | ⚙️ Settings > Connections | 設定画面内に格納 |
| Sprint Planner + Retrospective | 📊 Sprint | 統合画面 |

**画面数**: 9 → 5 + 設定

---

## 6. テストへの影響

| 変更 | テストへの影響 |
|------|--------------|
| core/git_analysis.rs新設 | 新規ユニットテスト追加。既存のchurn/diff テストを移動 |
| core/claude_gateway.rs新設 | claude_bridge テストをリネーム・移動 |
| review/ 統合 | PrQualityCheck + ReviewAgent のテストを統合 |
| policy/ 統合 | agent/policy + mcp/policy のテストを統合 |
| Phase番号変更 | E2Eシナリオ内のPhase参照を全更新 |

---

## 7. 設計書ファイルの変更

| 旧ファイル名 | 新ファイル名 | 変更 |
|-------------|-------------|------|
| doc-mapping-design.md | そのまま | diff_analyzerの委譲先を追記 |
| devnest-maintenance-strategy.md | そのまま | DocDrift参照先変更を追記 |
| devnest-multiproduct-agentic.md | そのまま | claude_bridge→gateway変更、Phase順序更新 |
| devnest-mcp-integration-design.md | そのまま | Phase番号9→7、削除機能の反映 |
| devnest-implementation-guide.md | **devnest-implementation-guide-v2.md** | Phase 1-5をcore層対応に更新 |
| devnest-phase6-10-implementation-plan.md | **devnest-implementation-plan-v2.md** | 再編後のPhase 6-10 |
| devnest-phase6-10-test-plan.md | **devnest-test-plan-v2.md** | 再編後に対応 |
| devnest-e2e-scenario-coverage.md | **devnest-e2e-spec-v2.md** | Phase番号更新、シナリオ追加 |
| (新規) | **devnest-unified-design.md** | 全Phase統合設計書 |
| (新規) | **devnest-core-layer-design.md** | core層の詳細設計 |
