# DevNest core層 詳細設計書

> **文書ID**: DESIGN-CORE
> **位置づけ**: 再編で新設される共通基盤層の詳細設計。全モジュールが参照する。

---

## 1. 概要

core層はDevNest全体で共有される基盤処理を提供する。
各ドメインモジュール（doc_mapping, maintenance, agent, ai, mcp, agile, analytics）は
core層を通じて外部リソース（Git, Claude Code, GitHub）にアクセスする。

### 設計原則
- **単一責任**: 各core モジュールは1つの外部リソースを抽象化
- **トレイトベース**: テスト時にモックへ差し替え可能
- **非同期**: 全APIが `async` で統一
- **エラー型統一**: `CoreError` を共通エラー型とし、各ドメインがラップ

---

## 2. core/git_analysis.rs

### 責務
Gitリポジトリに対する全ての読み取り分析を統一的に提供する。

### トレイト定義

```rust
#[async_trait]
pub trait GitAnalyzer: Send + Sync {
    /// 指定期間のコミット一覧を取得
    async fn get_commits(
        &self,
        repo_path: &Path,
        range: &DateRange,
    ) -> Result<Vec<CommitInfo>, CoreError>;

    /// ファイル別の変更頻度（churn）を取得
    async fn get_file_churn(
        &self,
        repo_path: &Path,
        range: &DateRange,
    ) -> Result<Vec<FileChurn>, CoreError>;

    /// 2つのコミット間のdiffを取得
    async fn get_diff(
        &self,
        repo_path: &Path,
        from: &str,
        to: Option<&str>,
    ) -> Result<DiffResult, CoreError>;

    /// ワーキングディレクトリの未コミット変更を取得
    async fn get_unstaged_changes(
        &self,
        repo_path: &Path,
    ) -> Result<DiffResult, CoreError>;

    /// コントリビューター一覧を取得
    async fn get_contributors(
        &self,
        repo_path: &Path,
        range: &DateRange,
    ) -> Result<Vec<Contributor>, CoreError>;

    /// 現在のHEADコミットハッシュを取得
    async fn get_head_commit(
        &self,
        repo_path: &Path,
    ) -> Result<String, CoreError>;

    /// 指定コミット以降の変更ファイル一覧
    async fn get_changed_files_since(
        &self,
        repo_path: &Path,
        since_commit: &str,
    ) -> Result<Vec<ChangedFile>, CoreError>;
}

// 本番実装
pub struct Git2Analyzer;

// テスト用モック
pub struct MockGitAnalyzer {
    pub commits: Vec<CommitInfo>,
    pub churn: Vec<FileChurn>,
    pub diff: DiffResult,
}
```

### データ型

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitInfo {
    pub hash: String,
    pub author: String,
    pub message: String,
    pub timestamp: DateTime<Utc>,
    pub files_changed: u32,
    pub lines_added: u32,
    pub lines_deleted: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileChurn {
    pub path: String,
    pub commit_count: u32,
    pub lines_added_total: u32,
    pub lines_deleted_total: u32,
    pub last_modified: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiffResult {
    pub changed_files: Vec<ChangedFile>,
    pub total_additions: u32,
    pub total_deletions: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChangedFile {
    pub path: String,
    pub change_type: ChangeType,
    pub additions: u32,
    pub deletions: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ChangeType {
    Added,
    Modified,
    Deleted,
    Renamed { from: String },
}
```

### 利用者マッピング

| 利用モジュール | 利用するAPI | 旧実装場所 |
|--------------|------------|-----------|
| doc_mapping/diff_analyzer | `get_diff()`, `get_changed_files_since()` | 自前のgit2呼び出し |
| doc_mapping/staleness | `get_head_commit()`, `get_commits()` | 自前のgit2呼び出し |
| maintenance/refactor | `get_file_churn()` | 自前のgit log解析 |
| analytics/velocity | `get_commits()`, `get_contributors()` | 自前のgit log解析 |
| agile/flow | `get_commits()` | 自前のgit log解析 |
| review/engine | `get_diff()` | 自前のgit2呼び出し |

---

## 3. core/claude_gateway.rs

### 責務
Claude Code CLIの呼び出しを統一的に管理する。
コンテキスト構築からプロンプト生成、実行、結果パースまでを一貫して担当。

### トレイト定義

```rust
#[async_trait]
pub trait ClaudeGateway: Send + Sync {
    /// Claude Codeにタスクを実行させる
    async fn execute(
        &self,
        request: ClaudeRequest,
        working_dir: &Path,
    ) -> Result<ClaudeResult, CoreError>;

    /// 実行状況をストリームで取得
    fn stream_progress(
        &self,
        execution_id: &str,
    ) -> Pin<Box<dyn Stream<Item = ProgressEvent> + Send>>;

    /// 利用可能かチェック（CLIの存在確認）
    async fn is_available(&self) -> bool;
}

#[derive(Debug, Clone)]
pub struct ClaudeRequest {
    pub prompt: String,
    pub context: ClaudeContext,
    pub timeout: Duration,
}

#[derive(Debug, Clone)]
pub struct ClaudeContext {
    /// 現在のファイルコンテキスト
    pub file_contexts: Vec<FileContext>,
    /// 関連設計書
    pub doc_contexts: Vec<DocContext>,
    /// 保守データ（カバレッジ、負債等）
    pub maintenance_snapshot: Option<MaintenanceSnapshot>,
    /// プロダクト情報
    pub product_info: Option<ProductInfo>,
    /// Git情報（最近の変更等）
    pub git_info: Option<GitInfo>,
}

#[derive(Debug, Clone)]
pub struct ClaudeResult {
    pub success: bool,
    pub output: String,
    pub files_changed: Vec<ChangedFile>,
    pub commits_made: Vec<String>,
    pub errors: Vec<String>,
    pub duration: Duration,
}
```

### コンテキスト構築（旧ContextEngine統合）

```rust
impl ClaudeGateway for ClaudeGatewayImpl {
    /// コンテキストを自動構築してプロンプトを生成
    pub fn build_context(
        &self,
        purpose: PromptPurpose,
        target: &ContextTarget,
        git_analyzer: &dyn GitAnalyzer,
        doc_index: &DocIndex,
    ) -> Result<ClaudeContext, CoreError> {
        // 1. target（ファイル or 設計書 or タスク）に応じて関連情報を収集
        // 2. doc-mapping からrelated docsを取得
        // 3. 保守データを取得
        // 4. トークン予算内に圧縮
        // 5. ClaudeContextとして返却
    }
}

pub enum ContextTarget {
    File(PathBuf),
    Document(PathBuf),
    Task(AgentTask),
    Diff(DiffResult),
}

pub enum PromptPurpose {
    CodeGeneration,
    CodeReview,
    DocUpdate,
    TestGeneration,
    RefactorSuggestion,
    DebugAssist,
}
```

### プロンプトテンプレート（旧claude_bridge統合）

```rust
impl ClaudeGatewayImpl {
    /// Purpose に応じたプロンプトを生成
    pub fn build_prompt(
        purpose: &PromptPurpose,
        context: &ClaudeContext,
    ) -> String {
        match purpose {
            PromptPurpose::CodeGeneration => { /* 設計書→コード生成 */ }
            PromptPurpose::CodeReview => { /* diff→レビュー */ }
            PromptPurpose::DocUpdate => { /* ソース変更→設計書更新 */ }
            PromptPurpose::TestGeneration => { /* カバレッジ不足→テスト生成 */ }
            _ => { /* 汎用 */ }
        }
    }
}
```

### 利用者マッピング

| 利用モジュール | 旧実装 | 用途 |
|--------------|--------|------|
| agent/engine | agent/claude_bridge.rs | Agentic Flowタスク実行 |
| ai/codegen | ai/context_engine.rs | 設計書駆動コード生成 |
| review/engine | ai/review_agent.rs | AIレビュー |

---

## 4. core/github_gateway.rs

### 責務
GitHub操作を統一的に提供する。MCP経由とAPI直接を自動切替する。

### トレイト定義

```rust
#[async_trait]
pub trait GitHubGateway: Send + Sync {
    // ── リポジトリ ──
    async fn list_repos(&self, filter: &RepoFilter) -> Result<Vec<RepoInfo>, CoreError>;
    async fn get_repo(&self, owner: &str, repo: &str) -> Result<RepoInfo, CoreError>;

    // ── Issue ──
    async fn create_issue(&self, repo: &RepoRef, issue: NewIssue) -> Result<Issue, CoreError>;
    async fn update_issue(&self, repo: &RepoRef, number: u32, update: IssueUpdate) -> Result<Issue, CoreError>;
    async fn list_issues(&self, repo: &RepoRef, filter: &IssueFilter) -> Result<Vec<Issue>, CoreError>;

    // ── Pull Request ──
    async fn create_pr(&self, repo: &RepoRef, pr: NewPr) -> Result<PullRequest, CoreError>;
    async fn get_pr_diff(&self, repo: &RepoRef, number: u32) -> Result<String, CoreError>;
    async fn add_pr_comment(&self, repo: &RepoRef, number: u32, body: &str) -> Result<(), CoreError>;
    async fn merge_pr(&self, repo: &RepoRef, number: u32) -> Result<(), CoreError>;

    // ── Release ──
    async fn create_release(&self, repo: &RepoRef, release: NewRelease) -> Result<Release, CoreError>;

    // ── Contributors ──
    async fn get_contributors(&self, repo: &RepoRef) -> Result<Vec<GitHubUser>, CoreError>;
}

/// MCP接続がある場合はMCP経由、なければoctocrab直接
pub struct GitHubGatewayImpl {
    mcp_hub: Option<Arc<McpHub>>,
    octocrab_client: Option<Arc<octocrab::Octocrab>>,
}

impl GitHubGatewayImpl {
    /// MCP Hubが利用可能ならMCP経由、そうでなければAPI直接
    fn resolve_transport(&self) -> TransportMethod {
        if let Some(hub) = &self.mcp_hub {
            if hub.is_server_connected("github") {
                return TransportMethod::Mcp;
            }
        }
        if self.octocrab_client.is_some() {
            return TransportMethod::DirectApi;
        }
        TransportMethod::Unavailable
    }
}
```

### 利用者マッピング

| 利用モジュール | 旧実装 | 用途 |
|--------------|--------|------|
| product/registry | product/github_sync.rs | リポジトリ同期 |
| agile/kanban | mcp/adapters/github.rs | Issue同期 |
| review/reporter | mcp/adapters/github.rs | PRコメント投稿 |
| collaboration/team | mcp/adapters/github.rs | コントリビューター情報 |

---

## 5. policy/ 統合ポリシーモジュール

```rust
// policy/engine.rs

pub struct PolicyEngine {
    global_rules: PolicyRules,
    product_overrides: HashMap<String, PolicyRules>,
}

pub struct PolicyRules {
    pub task_risk_levels: HashMap<TaskType, RiskLevel>,
    pub tool_access: ToolAccessRules,
    pub require_approval_default: bool,
}

pub enum PolicyDecision {
    Allow,
    RequireApproval { reason: String },
    Deny { reason: String },
}

impl PolicyEngine {
    /// 統合ポリシー判定
    /// Agentic Flowのリスクレベル + MCPツールアクセス を一括判定
    pub fn evaluate(
        &self,
        request: &PolicyRequest,
    ) -> PolicyDecision {
        // 1. ツールがblocked → Deny
        // 2. タスクのリスクレベルがHigh → RequireApproval
        // 3. ツールがrequire_approval → RequireApproval
        // 4. 呼び出し元がUI → Allow（ユーザー操作）
        // 5. それ以外 → ルール評価
    }
}

pub struct PolicyRequest {
    pub caller: Caller,
    pub action: PolicyAction,
    pub product_id: String,
}

pub enum PolicyAction {
    AgentTask { task_type: TaskType, risk: RiskLevel },
    McpToolCall { server_id: String, tool_name: String },
    Combined { task: TaskType, tool: String },
}

// policy/audit.rs
pub struct AuditLog {
    pub entries: Vec<AuditEntry>,
}

pub struct AuditEntry {
    pub timestamp: DateTime<Utc>,
    pub caller: Caller,
    pub action: PolicyAction,
    pub decision: PolicyDecision,
    pub product_id: String,
}
```

---

## 6. review/ 統合レビューモジュール

```rust
// review/engine.rs

pub struct ReviewEngine {
    claude_gateway: Arc<dyn ClaudeGateway>,
    git_analyzer: Arc<dyn GitAnalyzer>,
    doc_index: Arc<DocIndex>,
}

impl ReviewEngine {
    /// ローカルdiffのレビュー
    pub async fn review_diff(
        &self,
        repo_path: &Path,
        scope: ReviewScope,
    ) -> Result<ReviewResult, ReviewError>

    /// PRのレビュー（GitHub Gateway経由でdiff取得）
    pub async fn review_pr(
        &self,
        repo: &RepoRef,
        pr_number: u32,
        scope: ReviewScope,
        github: &dyn GitHubGateway,
    ) -> Result<ReviewResult, ReviewError>

    /// 設計書整合性チェックのみ
    pub async fn check_design_consistency(
        &self,
        changed_files: &[ChangedFile],
    ) -> Result<DesignConsistencyReport, ReviewError>
}

// review/findings.rs
#[derive(Debug, Serialize, Deserialize)]
pub struct ReviewResult {
    pub summary: String,
    pub findings: Vec<Finding>,
    pub design_report: DesignConsistencyReport,
    pub doc_updates_needed: Vec<String>,
    pub assessment: Assessment,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Finding {
    pub file: String,
    pub line_range: Option<(u32, u32)>,
    pub severity: Severity,
    pub category: Category,
    pub message: String,
    pub suggested_fix: Option<String>,
}

// review/reporter.rs
pub struct ReviewReporter;

impl ReviewReporter {
    /// PRコメント用のMarkdownに変換
    pub fn to_pr_comment(result: &ReviewResult) -> String

    /// DevNest UI用のJSON構造に変換
    pub fn to_ui_model(result: &ReviewResult) -> ReviewViewModel
}
```

---

## 7. モジュール間の依存関係（最終版）

```
core/
├── git_analysis        外部依存: git2
├── claude_gateway      外部依存: tokio::process (Claude CLI)
└── github_gateway      外部依存: mcp/hub (Optional), octocrab (Optional)

policy/
└── engine              依存: なし（純粋なルール評価）

doc_mapping/            依存: core/git_analysis
maintenance/            依存: core/git_analysis, doc_mapping/staleness
product/                依存: core/github_gateway
agent/                  依存: core/claude_gateway, policy/engine
review/                 依存: core/claude_gateway, core/git_analysis, core/github_gateway
ai/                     依存: core/claude_gateway, doc_mapping
mcp/                    依存: core/github_gateway(逆方向: github_gatewayがmcp/hubを参照)
agile/                  依存: core/git_analysis, core/github_gateway
analytics/              依存: core/git_analysis, maintenance/coverage, agile/kanban
collaboration/          依存: core/github_gateway, agile, analytics
```
