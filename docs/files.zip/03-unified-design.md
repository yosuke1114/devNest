# DevNest 統合設計書 v2

> **文書ID**: DESIGN-UNIFIED-V2
> **対象**: 全10Phase、再編後の統合アーキテクチャ
> **前提**: 機能統合レビューの結果を反映

---

## 1. システムアーキテクチャ全体像

```
┌─────────────────────────────────────────────────────────┐
│                     DevNest (Tauri v2)                   │
│                                                         │
│  ┌─ Frontend (React + TypeScript) ────────────────────┐ │
│  │                                                     │ │
│  │  🏠 Home Dashboard                                  │ │
│  │  📋 Project View [Kanban|Maintenance|Analytics|AI]  │ │
│  │  🤖 Agent Control                                   │ │
│  │  📊 Sprint (Planner + Retro + 年輪)                 │ │
│  │  ⚙️ Settings (Connections / Preferences)            │ │
│  │                                                     │ │
│  └─────────────────────┬───────────────────────────────┘ │
│                        │ Tauri invoke                    │
│  ┌─ Backend (Rust) ───┴───────────────────────────────┐ │
│  │                                                     │ │
│  │  ┌─ core/ ──────────────────────────────────────┐  │ │
│  │  │ git_analysis │ claude_gateway │ github_gateway│  │ │
│  │  └──────────────────────────────────────────────┘  │ │
│  │                                                     │ │
│  │  ┌─ policy/ ─┐                                     │ │
│  │  │ engine    │ ← 全モジュールの承認判定を一元化     │ │
│  │  └───────────┘                                     │ │
│  │                                                     │ │
│  │  ┌──────────┬──────────┬──────────┬──────────┐     │ │
│  │  │doc_map   │maintenance│product  │ agent    │     │ │
│  │  │(Ph1)     │(Ph2)     │(Ph3)    │(Ph4-5)   │     │ │
│  │  └──────────┴──────────┴──────────┴──────────┘     │ │
│  │                                                     │ │
│  │  ┌──────────┬──────────┬──────────┬──────────┐     │ │
│  │  │ai+review │ mcp      │ agile   │analytics │     │ │
│  │  │(Ph6)     │(Ph7)     │(Ph8)    │(Ph9)     │     │ │
│  │  └──────────┴──────────┴──────────┴──────────┘     │ │
│  │                                                     │ │
│  │  ┌──────────┐                                      │ │
│  │  │collabora-│                                      │ │
│  │  │tion(Ph10)│                                      │ │
│  │  └──────────┘                                      │ │
│  └─────────────────────────────────────────────────────┘ │
│                        │                                 │
└────────────────────────┼─────────────────────────────────┘
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
    ┌──────────┐  ┌──────────┐  ┌──────────┐
    │GitHub MCP│  │Slack MCP │  │Claude    │
    │Server    │  │Server    │  │Code CLI  │
    └──────────┘  └──────────┘  └──────────┘
```

---

## 2. Phase別設計サマリー

### Phase 1: ドキュメントマッピング基盤（6タスク）

Markdownの frontmatter に `mapping` フィールドを定義し、ソース↔設計書の対応を管理。
`.doc-map.yaml` 逆引きインデックスを自動生成。鮮度スコアで更新必要性を数値化。

主要モジュール: `doc_mapping/` (parser, index, diff_analyzer, staleness)
依存: `core/git_analysis`

### Phase 2: 保守管理基盤（5タスク）

依存スキャン(Cargo+npm)、技術的負債検出(TODO/FIXME/複雑度)、
テストカバレッジ収集(tarpaulin+vitest)、リファクタリング候補分析(Churn×Complexity)。

主要モジュール: `maintenance/` (dependency, tech_debt, coverage, refactor)
依存: `core/git_analysis`, `doc_mapping/staleness`

### Phase 3: マルチプロダクト基盤（4タスク）

GitHub連携でリポジトリ動的取得。`.devnest.yaml` でプロダクトプロファイル管理。
プロダクトスイッチャーでコンテキスト一括切替。ポートフォリオダッシュボード。

主要モジュール: `product/` (registry, profile, switcher, portfolio)
依存: `core/github_gateway`

### Phase 4: Agentic Flowエンジン（5タスク）

トリガー(Schedule/Threshold/Manual)、タスクキュー(優先度制御)、
承認ゲート、基本タスク実装(スキャン/パッチ/ドキュメント更新/テスト提案)。

主要モジュール: `agent/` (engine, trigger, task, approval, workflow)
依存: `core/claude_gateway`, `policy/engine`

### Phase 5: ワークフロー & PR連携（3タスク）

YAMLベースの複合ワークフロー定義・実行。PRフック連携。
保守レポート自動生成。

主要モジュール: `agent/workflow.rs` 拡張
依存: `agent/engine`

### Phase 6: 共通基盤 & AI開発アシスタント（7タスク）

**core層構築**: git_analysis, claude_gateway, github_gateway の3基盤。
**AI**: コンテキスト認識、設計書駆動コード生成。
**レビュー統合**: PrQualityCheck + AIレビューを統合レビューエンジンに。

主要モジュール: `core/`, `ai/`, `review/`
依存: `doc_mapping`, `maintenance`

### Phase 7: MCP統合基盤（7タスク）

MCP Client Hub構築。GitHub/Slack MCPアダプター。
ToolRegistry(名前空間管理)。ポリシー統合。
github_gateway にMCPトランスポートを追加。

主要モジュール: `mcp/`, `policy/`
依存: `core/github_gateway`(双方向連携)

### Phase 8: アジャイルエンジン（5タスク）

パーソナルカンバン(WIP制限付き)。GitHub Issue同期(MCP経由)。
AIスプリントプランナー。自動レトロスペクティブ + 年輪。フロー最適化。

主要モジュール: `agile/` (kanban, sprint_planner, retrospective, flow)
依存: `core/git_analysis`, `core/github_gateway`, `mcp/hub`

### Phase 9: 分析 & インサイト（4タスク）

開発速度メトリクス(core/git_analysis利用)。AI効果測定。
スプリント分析(agile/kanbanデータ参照)。統合ダッシュボード。

主要モジュール: `analytics/` (velocity, ai_impact, sprint)
依存: `core/git_analysis`, `maintenance/coverage`, `agile/kanban`

### Phase 10: 拡張 & コラボレーション（3タスク）

Redmine MCPアダプター（実需確認後）。チームダッシュボード。ナレッジ共有。

主要モジュール: `collaboration/` (team, knowledge), `mcp/adapters/redmine`
依存: `core/github_gateway`, `agile`, `analytics`

---

## 3. データフロー

```
Git Repository
    │
    ▼
core/git_analysis ──────────────────────────────────────┐
    │                                                    │
    ├──▶ doc_mapping  ──▶ .doc-map.yaml                  │
    │       │                                            │
    │       ▼                                            │
    ├──▶ maintenance ──▶ DependencyReport                │
    │       │              TechDebtReport                 │
    │       │              CoverageReport                 │
    │       │              RefactorCandidates             │
    │       │                                            │
    │       ▼                                            │
    ├──▶ review ─────▶ ReviewResult                      │
    │                     │                              │
    │                     ▼                              │
    │              core/github_gateway ──▶ PR Comment    │
    │                     │                              │
    │                     ▼                              │
    ├──▶ agile ──────▶ KanbanBoard                       │
    │       │            SprintPlan                       │
    │       │            Retrospective                   │
    │       │            YearRingEntry                    │
    │       │                                            │
    │       ▼                                            │
    └──▶ analytics ──▶ VelocityMetrics                   │
                         AiImpactMetrics                  │
                         SprintAnalysis                   │
                                                         │
core/claude_gateway ◀───── agent/engine                  │
    │                        │                           │
    ▼                        ▼                           │
Claude Code CLI        policy/engine ◀───────────────────┘
    │                        │
    ▼                        ▼
Generated Code          AuditLog
Updated Docs
Test Files
```

---

## 4. .devnest.yaml 統合スキーマ

```yaml
product:
  name: "DevNest"
  category: personal
  priority: high

tech_stack:
  languages: [rust, typescript]
  framework: tauri-v2
  package_managers: [cargo, pnpm]
  test_runners:
    rust: cargo-tarpaulin
    typescript: vitest

docs:
  root: "docs/"
  mapping_enabled: true
  frontmatter_format: yaml

maintenance:
  dependency_scan: true
  coverage_tracking: true
  debt_tracking: true
  scan_schedule: weekly

sprint:
  duration_weeks: 2
  start_day: monday
  naming: "Sprint {n}"

agentic:
  auto_tasks_enabled: true
  require_approval: true
  allowed_actions: [doc_update, dependency_patch, test_suggestion]

mcp:
  servers:
    github:
      enabled: true
      tool_policy:
        require_approval: [create_pull_request, merge_pull_request]
    slack:
      enabled: true
      config:
        default_channel: "#devnest-notifications"

coverage:
  overall_minimum: 70.0
  new_code_minimum: 80.0
  critical_paths:
    - "src/core/"
    - "src/commands/"
```

---

## 5. Rustモジュール構造（最終版）

```
src-tauri/src/
├── core/
│   ├── mod.rs
│   ├── git_analysis.rs
│   ├── claude_gateway.rs
│   └── github_gateway.rs
├── policy/
│   ├── mod.rs
│   ├── engine.rs
│   ├── rules.rs
│   └── audit.rs
├── doc_mapping/
│   ├── mod.rs
│   ├── types.rs
│   ├── parser.rs
│   ├── index.rs
│   ├── diff_analyzer.rs
│   └── staleness.rs
├── maintenance/
│   ├── mod.rs
│   ├── dependency.rs
│   ├── coverage.rs
│   ├── tech_debt.rs
│   └── refactor.rs
├── product/
│   ├── mod.rs
│   ├── registry.rs
│   ├── profile.rs
│   ├── switcher.rs
│   └── portfolio.rs
├── agent/
│   ├── mod.rs
│   ├── engine.rs
│   ├── trigger.rs
│   ├── task.rs
│   ├── approval.rs
│   ├── workflow.rs
│   └── result_store.rs
├── ai/
│   ├── mod.rs
│   └── codegen.rs
├── review/
│   ├── mod.rs
│   ├── engine.rs
│   ├── findings.rs
│   └── reporter.rs
├── mcp/
│   ├── mod.rs
│   ├── hub.rs
│   ├── connection.rs
│   ├── config.rs
│   ├── tool_registry.rs
│   ├── transport_factory.rs
│   └── adapters/
│       ├── mod.rs
│       ├── github.rs
│       └── slack.rs
├── agile/
│   ├── mod.rs
│   ├── kanban.rs
│   ├── sprint_planner.rs
│   ├── retrospective.rs
│   └── flow.rs
├── analytics/
│   ├── mod.rs
│   ├── velocity.rs
│   ├── ai_impact.rs
│   └── sprint.rs
├── collaboration/
│   ├── mod.rs
│   ├── team.rs
│   └── knowledge.rs
└── commands/
    ├── doc_mapping_commands.rs
    ├── maintenance_commands.rs
    ├── product_commands.rs
    ├── agent_commands.rs
    ├── ai_commands.rs
    ├── review_commands.rs
    ├── mcp_commands.rs
    ├── agile_commands.rs
    ├── analytics_commands.rs
    └── collaboration_commands.rs
```

---

## 6. UI画面構成（最終版）

### 🏠 Home Dashboard
- ポートフォリオヘルスサマリー（全プロダクト横断）
- Attention Requiredパネル（優先度の高い問題）
- Agent Activityパネル（実行中/完了タスク）
- クイックアクション（スキャン実行、プロダクト追加）

### 📋 Project View（タブ切替）
- **[Kanban]**: カンバンボード、WIP制限表示、Issue同期状態
- **[Maintenance]**: 保守4軸ダッシュボード（Deps/Debt/Coverage/Refactor）
- **[Analytics]**: 開発速度/AI効果/スプリント比較
- **[AI Review]**: レビュー実行、Finding表示、コード生成

### 🤖 Agent Control
- タスクキュー一覧（プロダクト別フィルタ）
- 承認待ちパネル（ExecutionPlan表示 + Approve/Reject）
- 実行ログ（進捗ストリーミング）
- トリガー設定

### 📊 Sprint
- スプリントプランニング（AIプラン提案 + 承認）
- レトロスペクティブ（自動生成 + 編集）
- 年輪レトロスペクティブ（成長の可視化）
- フロー分析（サイクルタイム/ボトルネック/WIP最適化）

### ⚙️ Settings
- **Connections**: MCP Server管理、GitHubアカウント管理
- **Preferences**: テーマ、通知設定、スプリント設定
- **Policies**: ツール別アクセス制御、承認ルール
