# DevNest 実装指示書 v2 — Claude Code向け（全32タスク）

> **目的**: 再編後の全10Phase・32タスクをClaude Codeで実装するための指示書。
> **変更**: v1からの差分は `01-change-summary.md` を参照。
> **ブランチ規則**: `feature/p<phase>-<task>` (例: `feature/p6-core-git`)
> **重要**: 各タスク完了時に設計書のfrontmatterとマッピングを必ず更新すること。

---

## 参照設計書

| 設計書 | 内容 |
|--------|------|
| `03-unified-design.md` | 全Phase統合設計 |
| `02-core-layer-design.md` | core層詳細設計 |
| `01-change-summary.md` | v1からの変更点 |

---

## Phase 1-5: 基盤（v1から軽微変更のみ）

> Phase 1-5の詳細タスクは `devnest-implementation-guide.md`（v1）を参照。
> 以下はv1からの**差分のみ**記載。

### Phase 1-5 差分適用タスク

**Task 0.1: v1実装済みコードへのcore層導入準備**

Phase 1-5が既に実装済みの場合、以下のリファクタリングを適用:

1. `doc_mapping/diff_analyzer.rs` のgit2直接呼び出しを `core/git_analysis` トレイト呼び出しに変更
2. `maintenance/refactor.rs` のchurn分析を `core/git_analysis` に委譲
3. `maintenance/tech_debt.rs` の DocDrift を `doc_mapping/staleness.rs` 参照に変更
4. `agent/claude_bridge.rs` を `core/claude_gateway.rs` に移動・リネーム
5. `product/github_sync.rs` を `core/github_gateway.rs` に移動・リネーム
6. `agent/policy.rs` を `policy/engine.rs` に移動

**完了条件**: 既存テストが全て通過すること。

---

## Phase 6: 共通基盤 & AI開発アシスタント（7タスク）

### Task 6.1: core/git_analysis.rs

**ファイル**: `src-tauri/src/core/git_analysis.rs`

**やること**:
1. `02-core-layer-design.md` のセクション2に従い `GitAnalyzer` トレイトを定義
2. `Git2Analyzer` 実装（`git2` クレート使用）
3. `MockGitAnalyzer` 実装（テスト用）
4. 全データ型（CommitInfo, FileChurn, DiffResult, ChangedFile）を定義
5. テスト: 各API関数のユニットテスト（TestRepo使用）

**完了条件**: `get_commits`, `get_file_churn`, `get_diff` が動作。MockでDIが可能。

**ドキュメント更新**: `docs/modules/rust-modules.md` に core モジュール追加

---

### Task 6.2: core/claude_gateway.rs

**ファイル**: `src-tauri/src/core/claude_gateway.rs`

**やること**:
1. `02-core-layer-design.md` のセクション3に従い `ClaudeGateway` トレイトを定義
2. 本番実装: Claude Code CLIをtokio::processで起動
3. コンテキスト構築: `build_context()` を実装（旧ContextEngine統合）
4. プロンプトテンプレート: Purpose別テンプレート（旧claude_bridge統合）
5. ストリーム進捗: Tauriイベントで配信
6. MockClaudeGateway実装（テスト用）

**完了条件**: CLIプロセス起動→プロンプト送信→結果取得が動作。

**ドキュメント更新**: `docs/core/claude-gateway.md` を新規作成

---

### Task 6.3: core/github_gateway.rs

**ファイル**: `src-tauri/src/core/github_gateway.rs`

**やること**:
1. `02-core-layer-design.md` のセクション4に従い `GitHubGateway` トレイトを定義
2. `GitHubGatewayImpl` 実装: MCP/API自動切替ロジック
3. 旧 `product/github_sync.rs` の機能を移行
4. MCP Hub への参照は `Option<Arc<McpHub>>`（Phase 7で接続）
5. octocrab直接呼び出しをフォールバックとして維持

**完了条件**: MCP未接続時はoctocrab直接、MCP接続時はMCP経由で動作。

**ドキュメント更新**: `docs/core/github-gateway.md` を新規作成

---

### Task 6.4: policy/ 統合ポリシーエンジン

**ファイル**: `src-tauri/src/policy/engine.rs`, `rules.rs`, `audit.rs`

**やること**:
1. `02-core-layer-design.md` のセクション5に従い PolicyEngine を実装
2. 旧 `agent/policy.rs` のリスクレベル判定を統合
3. 旧 `mcp/policy.rs`（Phase 7で実装予定）のツールアクセス制御枠を準備
4. AuditLog実装（全ポリシー判定を記録）
5. agent モジュールからは `policy::engine` を参照するよう変更

**完了条件**: AgentTaskのポリシー判定が policy/engine 経由で動作。

**ドキュメント更新**: `docs/policy/policy-engine.md` を新規作成

---

### Task 6.5: review/ 統合レビューエンジン

**ファイル**: `src-tauri/src/review/engine.rs`, `findings.rs`, `reporter.rs`

**やること**:
1. `02-core-layer-design.md` のセクション6に従い ReviewEngine を実装
2. `review_diff()`: ローカルdiffのAIレビュー
3. `review_pr()`: PR diffの取得（github_gateway経由）+ AIレビュー
4. `check_design_consistency()`: doc-mapping連携の設計書整合性チェック
5. ReviewReporter: PRコメント用Markdown変換 + UI用ViewModel変換
6. 旧 `agent/task.rs` の PrQualityCheck ハンドラを `review_pr()` への委譲に変更

**完了条件**: ローカルdiff/PRの両方でレビューが実行できる。

**ドキュメント更新**: `docs/review/review-engine.md` を新規作成

---

### Task 6.6: ai/codegen.rs

**ファイル**: `src-tauri/src/ai/codegen.rs`

**やること**:
1. 設計書の内容からコード骨格を生成する機能
2. `claude_gateway.execute()` を利用（コンテキスト自動構築）
3. 生成モード: Scaffold / Implementation / TestOnly
4. doc_type別の生成パターン（API→Rustシグネチャ、画面→React骨格等）
5. 生成後のdoc-mapping自動更新（mapping_updates返却）

```rust
#[tauri::command]
pub async fn generate_code_from_doc(
    project_path: String,
    request: CodegenRequest,
) -> Result<CodegenResult, AppError>
```

**完了条件**: API定義設計書からRust骨格、画面設計書からReact骨格が生成できる。

**ドキュメント更新**: `docs/ai/codegen.md` を新規作成

---

### Task 6.7: AI & レビュー UI

**ファイル**: `src/components/ProjectView/AiReviewTab.tsx`

**やること**:
1. Project Viewの [AI Review] タブとして実装
2. レビュー実行パネル（スコープ選択、実行ボタン）
3. Finding一覧（ファイル別グルーピング、severity別アイコン）
4. 設計書整合性レポート表示
5. 「設計書からコード生成」ボタン
6. 「Fix suggestion適用」ワンクリック

**完了条件**: UIからレビュー実行・結果表示・コード生成が可能。

**ドキュメント更新**: `docs/screens/project-view.md` に AI Review タブを追記

---

## Phase 7: MCP統合基盤（7タスク）

### Task 7.1: MCP Client Hub

**ファイル**: `src-tauri/src/mcp/hub.rs`, `connection.rs`, `config.rs`

**やること**:
1. `rmcp` クレート(v0.16+)を Cargo.toml に追加
2. McpHub 実装（接続管理、ライフサイクル、reconnect）
3. `mcp-config.yaml` パーサー
4. stdio/SSE トランスポート対応
5. Tauriコマンド: `initialize_mcp_hub`, `get_mcp_status`, `connect_mcp_server`, `disconnect_mcp_server`

**完了条件**: 任意のMCP Serverにstdio/SSEで接続しツール一覧が取得できる。

**ドキュメント更新**: `docs/mcp/hub.md` を新規作成

---

### Task 7.2: ToolRegistry

**ファイル**: `src-tauri/src/mcp/tool_registry.rs`

**やること**:
1. 全サーバーのツールを名前空間付きで集約
2. 完全修飾名(github.create_issue) / 短縮名(create_issue)の解決
3. 曖昧な場合は候補リストを返す
4. サーバー追加/削除時のインデックス更新

**完了条件**: ツール名からサーバーが一意に解決できる。

---

### Task 7.3: ポリシー統合（MCPツール制御追加）

**ファイル**: `src-tauri/src/policy/engine.rs` を拡張

**やること**:
1. Task 6.4で構築したPolicyEngineにMCPツールアクセス制御を追加
2. `PolicyAction::McpToolCall` のハンドリング
3. `mcp-config.yaml` の tool_policy を PolicyRules に変換
4. プロダクト別オーバーライドの適用

**完了条件**: MCPツール呼び出しがポリシーエンジン経由で制御される。

---

### Task 7.4: GitHub MCPアダプター

**ファイル**: `src-tauri/src/mcp/adapters/github.rs`

**やること**:
1. GitHub MCP Server接続（`@modelcontextprotocol/server-github`）
2. 高レベルAPI（create_maintenance_issue, create_agent_pr, add_doc_impact_comment等）
3. `core/github_gateway` にMCPトランスポートを登録
4. Agentic Flow統合: `PlannedAction::McpToolCall` の追加

**完了条件**: DevNestからMCP経由でGitHub Issue/PR操作ができる。

---

### Task 7.5: Slackアダプター

**ファイル**: `src-tauri/src/mcp/adapters/slack.rs`

**やること**:
1. Slack MCP Server接続
2. 通知送信、アラート送信、レポート送信
3. Agentic Flow完了通知の統合

**完了条件**: DevNestからSlackメッセージが送信できる。

---

### Task 7.6: github_gateway MCP統合

**やること**:
1. `core/github_gateway.rs` の `resolve_transport()` にMCP Hub参照を接続
2. McpHub接続時は自動的にMCP経由に切替
3. MCP切断時はoctocrabフォールバック
4. 切替の透過性テスト

**完了条件**: MCP接続有無でGitHub操作の経路が自動切替される。

---

### Task 7.7: MCP管理UI

**ファイル**: `src/components/Settings/ConnectionsTab.tsx`

**やること**:
1. Settings画面のConnectionsタブとして実装
2. サーバー接続状態一覧（Connected/Disconnected/Error）
3. ツールエクスプローラー（サーバー別ツール一覧 + ポリシー表示）
4. サーバー追加/削除/設定変更フォーム

**完了条件**: UIから接続管理・ツール確認ができる。

---

## Phase 8: アジャイルエンジン（5タスク）

### Task 8.1: パーソナルカンバン

**ファイル**: `src-tauri/src/agile/kanban.rs`, `src/components/ProjectView/KanbanTab.tsx`

**やること**:
1. KanbanBoard/KanbanColumn/KanbanCard データモデル
2. WIP制限エンジン
3. カードリンク（GitHub Issue / 設計書 / 技術的負債）
4. 自動ルール（PR Merged→Done等）
5. ドラッグ&ドロップ対応UI

**完了条件**: カンバンのCRUD + WIP制限が動作する。

---

### Task 8.2: GitHub Issue同期

**やること**:
1. `core/github_gateway` 経由でIssue取得→カンバンカード変換
2. カード列移動→Issueラベル更新の双方向同期
3. オフライン時のローカル操作継続

**完了条件**: Issue↔カードの双方向同期が動作する。

---

### Task 8.3: AIスプリントプランナー

**ファイル**: `src-tauri/src/agile/sprint_planner.rs`

**やること**:
1. バックログ + 過去ベロシティ + 保守タスク → AIプラン提案
2. `core/claude_gateway` でプラン生成
3. プラン承認→カンバン反映

**完了条件**: AIがスプリントプランを提案し、承認でカンバンに反映される。

---

### Task 8.4: 自動レトロスペクティブ + 年輪

**ファイル**: `src-tauri/src/agile/retrospective.rs`

**やること**:
1. スプリント完了時にデータから自動生成（went_well / could_improve / action_items）
2. 年輪レトロスペクティブ（YearRingEntry蓄積）
3. action_items → 次スプリントBacklog自動追加
4. Sprint画面のレトロタブで表示・編集

**完了条件**: レトロスペクティブが自動生成され、年輪が蓄積される。

---

### Task 8.5: フロー最適化

**ファイル**: `src-tauri/src/agile/flow.rs`

**やること**:
1. サイクルタイム/スループット計測
2. ボトルネック検出
3. WIP制限最適化提案
4. リトルの法則によるリードタイム予測

**完了条件**: フロー分析結果がSprint画面に表示される。

---

## Phase 9: 分析 & インサイト（4タスク）

### Task 9.1: 開発速度メトリクス

**ファイル**: `src-tauri/src/analytics/velocity.rs`

**やること**:
1. `core/git_analysis` からコミット/churnデータ取得（自前で解析しない）
2. `maintenance/coverage` からカバレッジデータ参照
3. 設計書更新率（doc-mapping連携）算出
4. トレンドデータ（日次/週次/月次/スプリント）

**完了条件**: 全メトリクスが取得でき、トレンド表示が可能。

---

### Task 9.2: AI効果測定

**ファイル**: `src-tauri/src/analytics/ai_impact.rs`

**やること**:
1. Agentic Flow実行ログからタスク統計
2. AIコミット識別（prefix: `docs:`, `test:`, `deps:` 等）
3. 時間節約推定
4. ドキュメント保守効果

**完了条件**: AI活用の定量的効果が算出できる。

---

### Task 9.3: スプリント分析

**ファイル**: `src-tauri/src/analytics/sprint.rs`

**やること**:
1. `agile/kanban` のスプリントデータを参照（自前で集計しない）
2. 保守デルタ（開始時 vs 終了時）
3. ハイライト/懸念の自動検出
4. スプリント履歴比較

**完了条件**: スプリント分析が Phase 8 のデータに基づいて動作。

---

### Task 9.4: 分析ダッシュボードUI

**ファイル**: `src/components/ProjectView/AnalyticsTab.tsx`

**やること**:
1. Project Viewの [Analytics] タブとして実装
2. 開発速度トレンド（recharts LineChart）
3. AI効果サマリーパネル
4. スプリント比較パネル
5. 期間フィルタ（日/週/月/スプリント）

**完了条件**: 4パネルが表示され、フィルタが動作する。

---

## Phase 10: 拡張 & コラボレーション（3タスク）

### Task 10.1: Redmine MCPアダプター（実需確認後）

**ファイル**: `src-tauri/src/mcp/adapters/redmine.rs`

**やること**: 職場での実需が確認された段階で実装。チケット同期、工数取得。

---

### Task 10.2: チームダッシュボード

**ファイル**: `src-tauri/src/collaboration/team.rs`, `src/components/TeamDashboard.tsx`

**やること**:
1. `core/github_gateway` 経由でコントリビューター情報取得
2. メンバー別活動サマリー
3. レビュー待ちPR集約
4. 個人モード（チーム未設定）での安全な動作

**完了条件**: チームメンバーの活動が一覧表示される。

---

### Task 10.3: ナレッジ共有

**ファイル**: `src-tauri/src/collaboration/knowledge.rs`

**やること**:
1. ナレッジエントリのCRUD
2. タグ/プロダクト/KnowledgeType別フィルタ
3. 全文検索
4. 設計書へのリンク + コメント機能

**完了条件**: ナレッジの登録・検索・閲覧が可能。

---

## ドキュメント更新チェックリスト

### 各Phase完了時
- [ ] 新規Rustモジュールが `docs/modules/rust-modules.md` に記載
- [ ] 新規Tauriコマンドが `docs/api/tauri-commands.md` に記載
- [ ] 新規画面の設計書が作成されている
- [ ] 変更した設計書の `last_synced_commit` を更新
- [ ] 変更した設計書の `version` をセマンティック更新
- [ ] 変更した設計書の `status` を `current` に
- [ ] `.doc-map.yaml` を再生成して整合性確認

### 最終チェック
- [ ] core/のテストカバレッジが90%以上
- [ ] 全テスト通過
- [ ] `cargo clippy` 警告なし
- [ ] フロントエンドlintエラーなし
