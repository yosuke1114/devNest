# DevNest テスト計画 v2（再編後）

> **文書ID**: TEST-V2
> **対象**: 全10Phase・32タスク、再編後のモジュール構造に対応
> **テスト方針**: Classical School TDD、外部依存はトレイトベースのモックでDI
> **カバレッジ目標**: 新規コード80%、core層90%、クリティカルパス90%

---

## テスト対象モジュールと規模

| モジュール | ユニット | 統合 | Phase |
|-----------|---------|------|-------|
| core/git_analysis | 15 | 3 | 6 |
| core/claude_gateway | 12 | 2 | 6 |
| core/github_gateway | 10 | 3 | 6 |
| policy/engine | 14 | 2 | 6 |
| review/engine | 12 | 3 | 6 |
| ai/codegen | 8 | 1 | 6 |
| mcp/hub | 10 | 4 | 7 |
| mcp/tool_registry | 8 | - | 7 |
| mcp/adapters/* | 12 | 3 | 7 |
| agile/kanban | 15 | 4 | 8 |
| agile/sprint_planner | 8 | 1 | 8 |
| agile/retrospective | 10 | 1 | 8 |
| agile/flow | 8 | - | 8 |
| analytics/* | 12 | 2 | 9 |
| collaboration/* | 8 | 2 | 10 |
| **合計** | **~162** | **~31** | |

---

## 共通テストインフラ

**ファイル**: `src-tauri/tests/common/mod.rs`

```rust
// TestRepo: テスト用Git リポジトリ（tempdir + git2）
// MockGitAnalyzer: core/git_analysis のモック
// MockClaudeGateway: core/claude_gateway のモック
// MockGitHubGateway: core/github_gateway のモック
// MockMcpServer: stdio ベースのフェイクMCPサーバー
// FixedClock: 時刻固定用
// sample_frontmatter_doc(): サンプル設計書生成
// sample_devnest_yaml(): サンプル設定生成
```

---

## Phase 6: core層 + AI テスト

### T-6.1: core/git_analysis（15ケース）

```
正常系:
  ✅ 指定期間のコミット一覧が取得できる
  ✅ author別の集計が正しい
  ✅ ファイル別churnが正しく集計される
  ✅ 2コミット間のdiffが取得できる
  ✅ 未コミット変更（unstaged）が取得できる
  ✅ コントリビューター一覧が取得できる
  ✅ HEADコミットハッシュが取得できる
  ✅ 指定コミット以降の変更ファイル一覧が取得できる
  ✅ ChangeType（Added/Modified/Deleted/Renamed）が正しく判定される

異常系:
  ✅ 存在しないリポジトリパスでエラー
  ✅ 存在しないコミットハッシュでエラー
  ✅ 空のリポジトリ（コミットなし）で空リスト

エッジ:
  ✅ バイナリファイルの変更がlines=0で返る
  ✅ マージコミットの処理
  ✅ 非常に大きなリポジトリでタイムアウトしない
```

### T-6.2: core/claude_gateway（12ケース）

```
正常系:
  ✅ CLIプロセスが起動しプロンプトが送信される（MockProcess）
  ✅ 結果がパースされClaudeResultに変換される
  ✅ コンテキスト構築でdoc-mappingから関連設計書が収集される
  ✅ PromptPurpose別にテンプレートが切り替わる
  ✅ トークン予算内にコンテキストが圧縮される
  ✅ ストリーム進捗イベントが配信される

異常系:
  ✅ CLIが存在しない場合 is_available()=false
  ✅ プロセスがタイムアウトした場合エラー
  ✅ CLIがエラー終了した場合にerrors配列に含まれる

エッジ:
  ✅ 空のコンテキスト（ファイルなし、設計書なし）でも動作
  ✅ トークン予算0でもクラッシュしない
  ✅ 循環依存の設計書でスタックオーバーフローしない
```

### T-6.3: core/github_gateway（10ケース）

```
正常系:
  ✅ MCP未接続時にoctocrabで直接API呼び出し
  ✅ MCP接続時にMCP経由でAPI呼び出し
  ✅ MCP接続中に切断→自動フォールバック
  ✅ Issue作成/更新/一覧が動作する
  ✅ PR作成/diff取得/コメント追加が動作する

異常系:
  ✅ MCP未接続 かつ octocrab未設定 → Unavailableエラー
  ✅ API呼び出し失敗時のエラーハンドリング

エッジ:
  ✅ 両トランスポートが同時に利用可能な場合MCP優先
  ✅ トークン期限切れ時のリフレッシュ
  ✅ レート制限時のリトライ
```

### T-6.4: policy/engine（14ケース）

```
正常系:
  ✅ AgentTaskのリスクレベルが正しく判定される
  ✅ MCPツールのallowed → Allow
  ✅ MCPツールのblocked → Deny
  ✅ MCPツールのrequire_approval → RequireApproval
  ✅ UI経由はrequire_approvalツールもAllow
  ✅ Agent経由はrequire_approvalツールでRequireApproval
  ✅ Combined判定（タスク+ツール）が正しく動作
  ✅ AuditLogに全判定が記録される

異常系:
  ✅ 未知のツール名 → Deny（安全側デフォルト）
  ✅ Caller情報なし → Deny

エッジ:
  ✅ ワイルドカード "admin_*" マッチ
  ✅ プロダクト別オーバーライドの適用
  ✅ グローバルblockedはオーバーライド不可
  ✅ 空のrules設定でデフォルト動作
```

### T-6.5: review/engine（12ケース）

```
正常系:
  ✅ ローカルdiffのレビューが実行される
  ✅ PRのレビューが実行される（MockGitHubGateway使用）
  ✅ 設計書整合性チェックでoutdated設計書が検出される
  ✅ 新規ファイルに設計書がない場合Info Finding
  ✅ ReviewScope::DesignConsistencyで設計書チェックのみ
  ✅ ReviewScope::Fullで全観点実行
  ✅ ReviewReporter.to_pr_comment()でMarkdown生成

異常系:
  ✅ 空のdiffで「変更なし」結果
  ✅ Claude Gateway失敗時のエラーハンドリング

エッジ:
  ✅ 設計書が1つもないプロダクトでも動作
  ✅ 非常に大きなdiffでのコンテキスト圧縮
  ✅ Finding.suggested_fixが実在するコードパターン
```

### T-6.6: ai/codegen（8ケース）

```
  ✅ API定義設計書→Rust関数シグネチャ骨格
  ✅ 画面設計書→React骨格
  ✅ Scaffoldモード=実装なし骨格のみ
  ✅ TestOnlyモード=テストコードのみ
  ✅ 生成後にmapping_updatesが返される
  ✅ frontmatter無し設計書→エラー
  ✅ 未知のdoc_type→汎用骨格
  ✅ 既存ファイルとの衝突検出
```

---

## Phase 7-10 テスト（要約）

### Phase 7: MCP統合（30ケース）

```
mcp/hub: 接続/切断/再接続/ヘルスチェック/プロダクト切替再構成
mcp/tool_registry: 完全修飾名解決/短縮名解決/曖昧/NotFound/カテゴリ分類
mcp/adapters: GitHub Issue/PR操作、Slack通知、全操作のMockMcpServer検証
```

### Phase 8: アジャイル（41ケース）

```
agile/kanban: CRUD/WIP制限/リンク/自動ルール/GitHub Issue同期/負債インポート
agile/sprint_planner: プラン生成/保守タスク組み込み/承認反映/空バックログ
agile/retrospective: 自動生成/年輪/アクション引き継ぎ
agile/flow: サイクルタイム/スループット/ボトルネック/WIP最適化提案
```

### Phase 9: 分析（22ケース）

```
analytics/velocity: コミット集計/churn/設計書更新率/トレンド/ゼロデータ
analytics/ai_impact: タスク統計/コード貢献/時間節約/ドキュメント保守
analytics/sprint: スプリント判定/保守デルタ/ハイライト検出/履歴
```

### Phase 10: コラボ（10ケース）

```
collaboration/team: メンバー集計/レビュー待ち/個人モード安全動作
collaboration/knowledge: CRUD/タグ検索/全文検索/コメント
```

---

## E2Eテスト（23シナリオ）

> 詳細は `06-e2e-spec-v2.md` を参照。ここではサマリーのみ。

| カテゴリ | シナリオ数 | 主要フロー |
|---------|----------|-----------|
| A: コア開発 | 3 | 設計書→生成→レビュー→マージ |
| B: 分析 | 3 | メトリクス、AI効果、ポートフォリオ横断 |
| C: アジャイル | 5 | スプリントライフサイクル、Issue同期、フロー最適化 |
| D: 外部統合 | 5 | MCP連携、障害フォールバック、ポリシー |
| E: コラボ | 4 | チーム、ナレッジ、エージェント |
| F: 横断 | 3 | 全Phase貫通統合フロー |

---

## テスト実行コマンド

```bash
# Phase別テスト
cargo test core::           # Phase 6 core
cargo test policy::         # Phase 6 policy
cargo test review::         # Phase 6 review
cargo test ai::             # Phase 6 AI
cargo test mcp::            # Phase 7
cargo test agile::          # Phase 8
cargo test analytics::      # Phase 9
cargo test collaboration::  # Phase 10

# 全テスト + カバレッジ
cargo tarpaulin --out json --output-dir .devnest/coverage/
pnpm test

# E2E
cargo test --test e2e
```
