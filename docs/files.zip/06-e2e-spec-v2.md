# DevNest E2E & ユーザーシナリオ 実装仕様書 v2

> **文書ID**: E2E-SPEC-V2
> **対象**: 再編後のPhase番号・モジュール構造に対応した23 E2Eシナリオ + 75ユーザーシナリオ

---

## 1. ユーザージャーニー（再編後Phase対応）

| ID | ジャーニー | 関連Phase(新) |
|----|----------|-------------|
| J-00〜J-07 | 既存（Phase 1-5対象） | 1-5 |
| J-08 | AIアシスタントで開発を加速する | **6** |
| J-09 | 開発のインパクトを振り返る | **9** (旧7) |
| J-10 | スプリントを回して成長を積み重ねる | **8** (旧8) |
| J-11 | 外部ツールをDevNestに集約する | **7** (旧9) |
| J-12 | チームの知見を蓄積・共有する | **10** |

---

## 2. E2Eシナリオ一覧（Phase番号更新済み）

### カテゴリA: コア開発フロー（Phase 6）

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-A1 | 設計書→コード生成→レビュー→マージ | core/claude_gateway + review/engine + core/github_gateway 連携 |
| E2E-A2 | 設計書整合性エラーの検出と修正提案 | review/engine の DesignConsistencyReport |
| E2E-A3 | テスト生成→カバレッジ改善 | ai/codegen(TestOnly) + maintenance/coverage |

### カテゴリB: 分析フロー（Phase 9）

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-B1 | スプリント分析→ハイライト検出 | analytics/* が core/git_analysis + agile/kanban を正しく参照 |
| E2E-B2 | AI効果ゼロからの計測開始 | ゼロデータ安全性 |
| E2E-B3 | ポートフォリオ横断分析 | product/portfolio + analytics の連携 |

### カテゴリC: アジャイルフロー（Phase 8）

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-C1 | スプリントフルライフサイクル | kanban→planner→retro→年輪→次スプリント |
| E2E-C2 | 空バックログからのスプリント開始 | ゼロデータ + 負債インポート |
| E2E-C3 | GitHub Issue同期付きカンバン | core/github_gateway + agile/kanban 双方向同期 |
| E2E-C4 | フロー最適化とWIP調整 | agile/flow ボトルネック検出 |
| E2E-C5 | 保守タスクのカンバン自動追加 | maintenance → agile/kanban 連携 |

### カテゴリD: 外部統合フロー（Phase 7）

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-D1 | 保守→Issue作成→Slack通知 | mcp/hub → adapters/github + slack 連鎖 |
| E2E-D2 | MCP接続障害時フォールバック | 部分障害でワークフロー続行 |
| E2E-D3 | プロダクト切替でMCP再構成 | mcp/hub.reconfigure_for_product() |
| E2E-D4 | ポリシー制御の動作検証 | policy/engine UI経由 vs Agent経由 |
| E2E-D5 | github_gateway MCP/API自動切替 | core/github_gateway の透過的切替 |

### カテゴリE: コラボフロー（Phase 10）

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-E1 | チームダッシュボード初回セットアップ | 個人モード安全動作 |
| E2E-E2 | ナレッジ蓄積→検索→活用 | クロスプロダクト検索 |
| E2E-E3 | 個人モードでのコラボ機能 | チーム未設定時の安全な無効化 |

### カテゴリF: 横断統合フロー

| ID | シナリオ | 検証ポイント |
|----|---------|------------|
| E2E-F1 | 設計書変更→保守→分析→レトロ一気通貫 | 全Phase連鎖 |
| E2E-F2 | 新規プロダクト初回セットアップ→本格運用 | ゼロ状態からの段階的有効化 |
| E2E-F3 | マルチプロダクト週次保守ワークフロー | 複数プロダクトの並列処理 |

---

## 3. E2Eシナリオ詳細仕様

### E2E-A1: 設計書→コード生成→レビュー→マージ

```
前提条件:
  - TestRepo に API定義設計書 docs/api/sample-api.md が存在
  - frontmatter: doc_type: api_definition, mapping.sources: []
  - MockClaudeGateway が Scaffold 結果を返すよう設定
  - MockGitHubGateway が PR作成成功を返すよう設定

実行ステップ:
  1. generate_code_from_doc(doc_path: "docs/api/sample-api.md", mode: Scaffold)
     → CodegenResult { generated_files: ["src/commands/sample_commands.rs"], mapping_updates: [...] }

  2. 生成ファイルが存在することを確認
     → assert!(Path::new("src/commands/sample_commands.rs").exists())

  3. 設計書のfrontmatterにmapping_updatesが適用されていることを確認
     → parse_frontmatter("docs/api/sample-api.md").mapping.sources.contains("src/commands/sample_commands.rs")

  4. review_diff(scope: Full)
     → ReviewResult { assessment: Approve, design_report.inconsistencies: [] }

  5. MockGitHubGateway.create_pr() が呼ばれる
     → PR body にdoc-impact分析が含まれる

  6. .doc-map.yaml を再生成
     → 新しいソースファイルがインデックスに含まれる

検証:
  assert_eq!(codegen_result.generated_files.len(), 1);
  assert!(frontmatter.mapping.sources.iter().any(|s| s.path.contains("sample_commands")));
  assert_eq!(review_result.assessment, Assessment::Approve);
  assert!(mock_github.get_call_log().iter().any(|c| c.method == "create_pr"));
```

### E2E-D5: github_gateway MCP/API自動切替（新規）

```
前提条件:
  - MockMcpServer(GitHub) が起動可能
  - octocrab のモック設定あり

実行ステップ:
  1. MCP未接続状態で github_gateway.list_repos() を呼ぶ
     → octocrab 経由で実行される（TransportMethod::DirectApi）

  2. MockMcpServer を起動して MCP Hub に接続
     → hub.connect_server("github")

  3. 同じ github_gateway.list_repos() を呼ぶ
     → MCP経由で実行される（TransportMethod::Mcp）

  4. MCP Serverを停止
     → hub のヘルスチェックが Disconnected を検出

  5. 再度 github_gateway.list_repos() を呼ぶ
     → octocrab にフォールバック（TransportMethod::DirectApi）

検証:
  assert_eq!(step1_transport, TransportMethod::DirectApi);
  assert_eq!(step3_transport, TransportMethod::Mcp);
  assert_eq!(step5_transport, TransportMethod::DirectApi);
  // 呼び出し元は切替を意識していないことを確認
  assert_eq!(step1_result.repos, step3_result.repos);
```

### E2E-F1: 全Phase貫通統合フロー

```
前提条件:
  - TestRepo に設計書、ソースコード、テストが存在
  - MockClaudeGateway, MockGitHubGateway, MockMcpServer 全設定
  - 2スプリント分の初期データ

実行ステップ:
  1. [Phase 6] 設計書を変更してコード生成
  2. [Phase 6] AIレビュー実行 → 設計書整合性OK
  3. [Phase 2] 保守スキャン → カバレッジ低下検出
  4. [Phase 4] Agentic Flow がテスト生成タスクを発行
  5. [Phase 6] テスト生成（MockClaudeGateway）→ カバレッジ回復
  6. [Phase 7] GitHub Issue 作成（MockMcpServer）
  7. [Phase 7] Slack 通知（MockMcpServer）
  8. [Phase 8] カンバンにカード自動追加 → Done に移動
  9. [Phase 8] スプリント完了 → レトロスペクティブ自動生成
  10. [Phase 9] スプリント分析にAI効果が反映
  11. [Phase 9] ハイライト「AI活用でN時間節約」が検出
  12. [Phase 10] 学びをナレッジに登録

検証:
  // 全Phase のデータが連鎖していることを確認
  assert!(sprint_analysis.ai_impact.tasks_executed > 0);
  assert!(retro.went_well.iter().any(|w| w.category == RetroCategory::AiEffectiveness));
  assert!(knowledge_entries.len() > 0);
  assert_eq!(doc_staleness.status, DocStatus::Current); // 全設計書が最新
```

---

## 4. ユーザーシナリオマトリクス（再編後Phase番号）

### Phase 6: 共通基盤 & AI

| ID | 分類 | シナリオ | テスト | E2E |
|----|------|---------|-------|-----|
| US-6.01 | 正常 | git_analysisでコミット集計 | T-6.1 | - |
| US-6.02 | 正常 | claude_gatewayでコンテキスト構築 | T-6.2 | E2E-A1 |
| US-6.03 | 正常 | github_gateway MCP自動切替 | T-6.3 | E2E-D5 |
| US-6.04 | 正常 | ポリシー判定 Allow/Approval/Deny | T-6.4 | E2E-D4 |
| US-6.05 | 正常 | 統合レビューで設計書整合性PASS | T-6.5 | E2E-A1 |
| US-6.06 | 正常 | 統合レビューで不整合検出 | T-6.5 | E2E-A2 |
| US-6.07 | 正常 | 設計書からコード骨格生成 | T-6.6 | E2E-A1 |
| US-6.08 | 正常 | 生成後doc-mapping自動更新 | T-6.6 | E2E-A1 |
| US-6.09 | 異常 | Claude CLI不在時の安全処理 | T-6.2 | - |
| US-6.10 | 異常 | GitHub両トランスポート不在時エラー | T-6.3 | - |
| US-6.11 | 異常 | 循環依存設計書の安全処理 | T-6.2 | - |
| US-6.12 | エッジ | トークン予算0でのコンテキスト | T-6.2 | - |
| US-6.13 | エッジ | 監査ログの全記録 | T-6.4 | E2E-D4 |

### Phase 7: MCP統合

| ID | 分類 | シナリオ | テスト | E2E |
|----|------|---------|-------|-----|
| US-7.01 | 正常 | Hub初期化→全サーバー接続 | T-7 | E2E-D1 |
| US-7.02 | 正常 | ツール名解決（完全修飾） | T-7 | - |
| US-7.03 | 正常 | GitHub Issue自動作成 | T-7 | E2E-D1 |
| US-7.04 | 正常 | Slack通知送信 | T-7 | E2E-D1 |
| US-7.05 | 正常 | プロダクト切替でMCP再構成 | T-7 | E2E-D3 |
| US-7.06 | 異常 | MCP接続失敗→エラー表示 | T-7 | E2E-D2 |
| US-7.07 | 異常 | 部分障害でワークフロー続行 | T-7 | E2E-D2 |
| US-7.08 | エッジ | 短縮名の曖昧解決 | T-7 | - |

### Phase 8: アジャイル

| ID | 分類 | シナリオ | テスト | E2E |
|----|------|---------|-------|-----|
| US-8.01 | 正常 | カンバンCRUD + WIP制限 | T-8 | E2E-C1 |
| US-8.02 | 正常 | GitHub Issue双方向同期 | T-8 | E2E-C3 |
| US-8.03 | 正常 | AIスプリントプラン提案 | T-8 | E2E-C1 |
| US-8.04 | 正常 | レトロスペクティブ自動生成 | T-8 | E2E-C1 |
| US-8.05 | 正常 | 年輪エントリ蓄積 | T-8 | E2E-C1 |
| US-8.06 | 正常 | ボトルネック検出 | T-8 | E2E-C4 |
| US-8.07 | 異常 | 空バックログでのプラン | T-8 | E2E-C2 |
| US-8.08 | 異常 | MCP接続断時のオフライン操作 | T-8 | E2E-C3 |
| US-8.09 | エッジ | 初回スプリント（データなし） | T-8 | E2E-C2 |

### Phase 9: 分析

| ID | 分類 | シナリオ | テスト | E2E |
|----|------|---------|-------|-----|
| US-9.01 | 正常 | 開発速度メトリクス取得 | T-9 | E2E-B1 |
| US-9.02 | 正常 | AI効果測定 | T-9 | E2E-B1 |
| US-9.03 | 正常 | スプリント比較ハイライト | T-9 | E2E-B1 |
| US-9.04 | 異常 | データゼロ時の安全表示 | T-9 | E2E-B2 |
| US-9.05 | エッジ | ポートフォリオ横断集計 | T-9 | E2E-B3 |

### Phase 10: コラボ

| ID | 分類 | シナリオ | テスト | E2E |
|----|------|---------|-------|-----|
| US-10.01 | 正常 | チームメンバー表示 | T-10 | E2E-E1 |
| US-10.02 | 正常 | ナレッジCRUD + 検索 | T-10 | E2E-E2 |
| US-10.03 | 異常 | 個人モードでの安全動作 | T-10 | E2E-E3 |

---

## 5. カバレッジサマリー（再編後）

| Phase | ユーザーシナリオ | ユニット/統合 | E2E |
|-------|---------------|-------------|-----|
| 6 | 13 | ~71 | A1,A2,A3,D4,D5 |
| 7 | 8 | ~30 | D1,D2,D3 |
| 8 | 9 | ~41 | C1,C2,C3,C4,C5 |
| 9 | 5 | ~22 | B1,B2,B3 |
| 10 | 3 | ~10 | E1,E2,E3 |
| 横断 | - | - | F1,F2,F3 |
| **合計** | **38** | **~174** | **23** |
