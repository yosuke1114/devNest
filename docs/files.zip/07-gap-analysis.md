# DevNest 追加設計書・手順書 ギャップ分析

> **文書ID**: GAP-001
> **目的**: 再編後のドキュメント体系で不足している設計書・手順書・実装手順書を特定する。

---

## 1. 現在のドキュメント一覧（v2）

| # | ファイル | 種別 | 状態 |
|---|---------|------|------|
| 1 | `01-change-summary.md` | 変更管理 | ✅ 作成済み |
| 2 | `02-core-layer-design.md` | 設計書 | ✅ 作成済み |
| 3 | `03-unified-design.md` | 統合設計書 | ✅ 作成済み |
| 4 | `04-implementation-guide-v2.md` | 実装指示書 | ✅ 作成済み |
| 5 | `05-test-plan-v2.md` | テスト計画 | ✅ 作成済み |
| 6 | `06-e2e-spec-v2.md` | E2E仕様書 | ✅ 作成済み |
| 7 | `devnest-feature-consolidation-review.md` | レビュー結果 | ✅ 作成済み（前回） |

---

## 2. 不足しているドキュメント

### 優先度: 高（実装開始前に必要）

| # | ドキュメント | 種別 | 理由 |
|---|------------|------|------|
| A | **マイグレーション手順書** | 手順書 | Phase 1-5実装済みコードをcore層に移行する具体的なステップ。Task 0.1を詳細化する必要がある |
| B | **共通テストインフラ実装仕様** | 実装仕様 | MockGitAnalyzer/MockClaudeGateway/MockMcpServer等の共通テストユーティリティの詳細実装。全テストの前提 |
| C | **Cargo.toml 依存管理ガイド** | 手順書 | rmcp, git2, octocrab, tokio-cron-scheduler 等の追加クレートの導入順序とfeature flag設定 |

### 優先度: 中（各Phase開始時に必要）

| # | ドキュメント | 種別 | 理由 |
|---|------------|------|------|
| D | **UI コンポーネント設計書** | 設計書 | 5画面のReactコンポーネントツリー、状態管理（useState/useReducer）、Tauriコマンド呼び出しパターンの定義。現状UIの設計粒度が粗い |
| E | **エラーハンドリング設計書** | 設計書 | CoreError/AppError/各ドメインエラーの階層構造、フロントエンドへの伝搬方法、ユーザー向けメッセージの定義 |
| F | **データ永続化設計書** | 設計書 | Registry(JSON), KanbanBoard, SprintData, AuditLog等の保存先・形式・マイグレーション方針。現状「JSONファイル」とだけ記載 |

### 優先度: 低（運用開始前に必要）

| # | ドキュメント | 種別 | 理由 |
|---|------------|------|------|
| G | **MCP Server 接続ガイド** | 手順書 | エンドユーザー向け。GitHub/Slack MCP Serverのセットアップ手順、トークン取得方法 |
| H | **DevNest 初回セットアップガイド** | 手順書 | エンドユーザー向け。インストール → .devnest.yaml 作成 → 初回スキャン の手順 |
| I | **トラブルシューティングガイド** | 手順書 | MCP接続失敗、Claude Code CLI不在、Git権限エラー等の対処法 |

---

## 3. 既存設計書の更新が必要な箇所

以下の旧設計書は再編前の構造を参照しているため、v2に合わせた更新が必要。

| 旧ドキュメント | 更新内容 | 担当タイミング |
|--------------|---------|-------------|
| `doc-mapping-design.md` | diff_analyzer → core/git_analysis 委譲を追記。Phase番号参照を更新 | Phase 6開始時 |
| `devnest-maintenance-strategy.md` | DocDrift → staleness参照に変更。core/git_analysis利用を追記 | Phase 6開始時 |
| `devnest-multiproduct-agentic.md` | claude_bridge → core/claude_gateway。Phase順序を全面更新 | Phase 6開始時 |
| `devnest-mcp-integration-design.md` | Phase 9→7。削除機能の反映。policy統合の反映 | Phase 7開始時 |

---

## 4. 推奨する対応順序

```
Step 1: マイグレーション手順書 (A) を作成
  → Phase 1-5既存コードのcore層移行を安全に実施

Step 2: 共通テストインフラ実装仕様 (B) を作成
  → 全テストの前提となるMock/TestRepoの実装

Step 3: Cargo.toml依存管理ガイド (C) を作成
  → クレート追加の順序を明確化

Step 4: Phase 6実装開始
  → 既存設計書の更新も同時実施

Step 5: UI コンポーネント設計書 (D) を作成
  → Phase 6のUI実装（Task 6.7）前に

Step 6: エラーハンドリング設計書 (E) を作成
  → Phase 7以降でエラー型が増える前に

Step 7: データ永続化設計書 (F) を作成
  → Phase 8（カンバン永続化）前に

Step 8: 運用ガイド (G, H, I) を作成
  → Phase 10完了後、リリース前に
```

---

## 5. ドキュメント体系の最終構成

```
docs/
├── design/                          設計書
│   ├── 01-change-summary.md            変更管理
│   ├── 02-core-layer-design.md         core層詳細設計
│   ├── 03-unified-design.md            全Phase統合設計
│   ├── doc-mapping-design.md           ドキュメントマッピング（更新）
│   ├── maintenance-strategy.md         保守戦略（更新）
│   ├── multiproduct-agentic.md         マルチプロダクト+Agent（更新）
│   ├── mcp-integration-design.md       MCP統合（更新）
│   ├── error-handling-design.md        エラーハンドリング（新規:E）
│   ├── data-persistence-design.md      データ永続化（新規:F）
│   └── ui-component-design.md          UIコンポーネント（新規:D）
│
├── implementation/                  実装文書
│   ├── 04-implementation-guide-v2.md   Claude Code実装指示書
│   ├── migration-guide.md              マイグレーション手順（新規:A）
│   └── cargo-dependency-guide.md       依存管理ガイド（新規:C）
│
├── testing/                         テスト文書
│   ├── 05-test-plan-v2.md              テスト計画
│   ├── 06-e2e-spec-v2.md              E2E仕様書
│   └── test-infra-spec.md             共通テストインフラ（新規:B）
│
└── guides/                          運用ガイド
    ├── setup-guide.md                  初回セットアップ（新規:H）
    ├── mcp-connection-guide.md         MCP接続ガイド（新規:G）
    └── troubleshooting.md              トラブルシューティング（新規:I）
```
